-- 自动生成的Lua配置文件
-- 源文件: attribute.xlsx

attribute = {
    [1] = {
        id = 1,
        name = "基础生命值",
        type = 1,
        display = 0,
        reduce = 0
    },
    [2] = {
        id = 2,
        name = "基础攻击力",
        type = 1,
        display = 0,
        reduce = 0
    },
    [3] = {
        id = 3,
        name = "基础攻击速度",
        type = 1,
        display = 0,
        reduce = 0
    },
    [4] = {
        id = 4,
        name = "基础移动速度",
        type = 1,
        display = 0,
        reduce = 0
    },
    [5] = {
        id = 5,
        name = "基础护盾能量",
        type = 1,
        display = 0,
        reduce = 0
    },
    [6] = {
        id = 6,
        name = "基础护盾能量回复间隔",
        type = 1,
        display = 0,
        reduce = 0
    },
    [7] = {
        id = 7,
        name = "基础护盾能量回复速度",
        type = 1,
        display = 0,
        reduce = 0
    },
    [8] = {
        id = 8,
        name = "基础护甲值",
        type = 1,
        display = 0,
        reduce = 0
    },
    [9] = {
        id = 101,
        name = "生命值",
        type = 1,
        display = 1,
        reduce = 0
    },
    [10] = {
        id = 102,
        name = "攻击力",
        type = 1,
        display = 1,
        reduce = 0
    },
    [11] = {
        id = 103,
        name = "攻击速度",
        type = 1,
        display = 1,
        reduce = 0
    },
    [12] = {
        id = 104,
        name = "移动速度",
        type = 1,
        display = 1,
        reduce = 0
    },
    [13] = {
        id = 105,
        name = "护盾能量",
        type = 1,
        display = 1,
        reduce = 0
    },
    [14] = {
        id = 106,
        name = "护盾能量回复间隔",
        type = 1,
        display = 1,
        reduce = 0
    },
    [15] = {
        id = 107,
        name = "护盾能量回复速度",
        type = 1,
        display = 1,
        reduce = 0
    },
    [16] = {
        id = 108,
        name = "护甲值",
        type = 1,
        display = 1,
        reduce = 1
    },
    [17] = {
        id = 111,
        name = "暴击几率",
        type = 2,
        display = 1,
        reduce = 0
    },
    [18] = {
        id = 112,
        name = "暴击伤害",
        type = 2,
        display = 1,
        reduce = 0
    },
    [19] = {
        id = 113,
        name = "暴击伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [20] = {
        id = 114,
        name = "固定护甲穿透",
        type = 1,
        display = 2,
        reduce = 0
    },
    [21] = {
        id = 115,
        name = "百分比护甲穿透",
        type = 2,
        display = 2,
        reduce = 0
    },
    [22] = {
        id = 116,
        name = "闪避几率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [23] = {
        id = 121,
        name = "全部伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [24] = {
        id = 122,
        name = "物理伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [25] = {
        id = 123,
        name = "全部伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [26] = {
        id = 124,
        name = "物理伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [27] = {
        id = 131,
        name = "寒风伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [28] = {
        id = 132,
        name = "结冰伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [29] = {
        id = 133,
        name = "雷暴伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [30] = {
        id = 134,
        name = "熔岩伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [31] = {
        id = 135,
        name = "重力伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [32] = {
        id = 136,
        name = "强磁伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [33] = {
        id = 137,
        name = "黑雾伤害转化率",
        type = 2,
        display = 2,
        reduce = 0
    },
    [34] = {
        id = 141,
        name = "额外寒风伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [35] = {
        id = 142,
        name = "额外结冰伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [36] = {
        id = 143,
        name = "额外雷暴伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [37] = {
        id = 144,
        name = "额外熔岩伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [38] = {
        id = 145,
        name = "额外重力伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [39] = {
        id = 146,
        name = "额外强磁伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [40] = {
        id = 147,
        name = "额外黑雾伤害",
        type = 1,
        display = 2,
        reduce = 0
    },
    [41] = {
        id = 148,
        name = "寒风伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [42] = {
        id = 149,
        name = "结冰伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [43] = {
        id = 150,
        name = "雷暴伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [44] = {
        id = 151,
        name = "熔岩伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [45] = {
        id = 152,
        name = "重力伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [46] = {
        id = 153,
        name = "强磁伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [47] = {
        id = 154,
        name = "黑雾伤害增加",
        type = 2,
        display = 2,
        reduce = 0
    },
    [48] = {
        id = 155,
        name = "寒风伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [49] = {
        id = 156,
        name = "结冰伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [50] = {
        id = 157,
        name = "雷暴伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [51] = {
        id = 158,
        name = "熔岩伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [52] = {
        id = 159,
        name = "重力伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [53] = {
        id = 160,
        name = "强磁伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [54] = {
        id = 161,
        name = "黑雾伤害减免",
        type = 2,
        display = 2,
        reduce = 1
    },
    [55] = {
        id = 201,
        name = "生命值增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [56] = {
        id = 202,
        name = "攻击力增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [57] = {
        id = 203,
        name = "攻击速度增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [58] = {
        id = 204,
        name = "移动速度增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [59] = {
        id = 205,
        name = "护盾能量增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [60] = {
        id = 206,
        name = "护盾能量回复间隔减少",
        type = 1,
        display = 0,
        reduce = 1
    },
    [61] = {
        id = 207,
        name = "护盾能量回复速度增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [62] = {
        id = 208,
        name = "护甲值增加",
        type = 1,
        display = 0,
        reduce = 1
    },
    [63] = {
        id = 301,
        name = "基础生命值加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [64] = {
        id = 302,
        name = "基础攻击力加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [65] = {
        id = 303,
        name = "基础攻击速度加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [66] = {
        id = 304,
        name = "基础移动速度加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [67] = {
        id = 305,
        name = "基础护盾能量加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [68] = {
        id = 306,
        name = "基础护盾能量回复间隔缩减",
        type = 2,
        display = 0,
        reduce = 1
    },
    [69] = {
        id = 307,
        name = "基础护盾能量回复速度加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [70] = {
        id = 308,
        name = "基础护甲值加成",
        type = 2,
        display = 0,
        reduce = 1
    },
    [71] = {
        id = 401,
        name = "生命值加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [72] = {
        id = 402,
        name = "攻击力加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [73] = {
        id = 403,
        name = "攻击速度加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [74] = {
        id = 404,
        name = "移动速度加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [75] = {
        id = 405,
        name = "护盾能量加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [76] = {
        id = 406,
        name = "护盾能量回复间隔加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [77] = {
        id = 407,
        name = "护盾能量回复速度加成",
        type = 2,
        display = 1,
        reduce = 1
    },
    [78] = {
        id = 408,
        name = "护甲值加成",
        type = 2,
        display = 1,
        reduce = 1
    },
}

return attribute