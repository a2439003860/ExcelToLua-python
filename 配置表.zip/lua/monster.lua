-- 自动生成的Lua配置文件
-- 源文件: monster.xlsx

monster = {
    [1] = {
        id = 1,
        name = "小鬼1",
        type = 0,
        icon = "",
        data = "100001",
        attackmode = 0,
        bulletID = 0,
        delay = 0,
        closeUp = 0,
        collision_injury = 0,
        collision_range = 0,
        att = {{1, 100}, {2, 10}},
        btree = ""
    },
    [2] = {
        id = 2,
        name = "小鬼2",
        type = 0,
        icon = "",
        data = "100001",
        attackmode = 3,
        bulletID = 110002,
        delay = 0,
        closeUp = 120,
        collision_injury = 1,
        collision_range = 0,
        att = {{1, 100}, {2, 1}},
        btree = ""
    },
    [3] = {
        id = 3,
        name = "小鬼3",
        type = 0,
        icon = "",
        data = "100001",
        attackmode = 1,
        bulletID = 110001,
        delay = 100,
        closeUp = 0,
        collision_injury = 1,
        collision_range = 0,
        att = {{1, 100}, {2, 1}, {3, 100}},
        btree = ""
    },
}

return monster