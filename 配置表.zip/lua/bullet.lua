-- 自动生成的Lua配置文件
-- 源文件: bullet.xlsx

bullet = {
    [1] = {
        id = 110001,
        animID = "110001",
        laser = 0,
        angle = 0,
        hit_size = {50},
        launch = {0, 0},
        speed = 500,
        acceleration = 0,
        survive = 15000,
        effect = {1100011},
        trace = 0,
        swerve = 0
    },
    [2] = {
        id = 110002,
        animID = "110002",
        laser = 0,
        angle = 0,
        hit_size = {150},
        launch = {0, 0},
        speed = 0,
        acceleration = 0,
        survive = 100,
        effect = {1100012},
        trace = 0,
        swerve = 0
    },
}

return bullet