-- 自动生成的Lua配置文件
-- 源文件: bullet_performance.xlsx

bullet_performance = {
    [1] = {
        id = 110001,
        mode = 0,
        animfileStart = "",
        animfileDefault = "T10001",
        animfileEnd = "",
        offset = {100, 0}
    },
    [2] = {
        id = 110002,
        mode = 2,
        animfileStart = "",
        animfileDefault = "T10002",
        animfileEnd = "",
        offset = {0, 0}
    },
}

return bullet_performance