-- 自动生成的Lua配置文件
-- 源文件: dungeon.xlsx

dungeon = {
    [1] = {
        id = 10001,
        name_l = "第一关-测试关卡",
        name_s = "测试关卡",
        progress_display = 1,
        time_display = 0,
        time_level = 1800,
        level_file = "test_map_10001",
        display = "杀死（%s/5）个任意怪物/n到达目的地（%s%/100%）",
        completed = {{3, 5}, {1, 10000}},
        resurrection = {0, 0},
        lose = {{2, 10}}
    },
}

return dungeon